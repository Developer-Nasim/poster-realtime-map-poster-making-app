<?php $__env->startSection('thecontents'); ?> 

    <div class="editor-header">
        <div class="header-top text-center">
            <p><b>Summer Sale!</b> Get 50% off your second poster + FREE shipping</p>
        </div>
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-8 offset-lg-4 text-end">
                    <div class="HeaderEditorContent">
                        <a class="editorHeaderLogo" href="#">
                            <svg viewBox="0 0 196 65" fill="#324549" class="hidden max-h-16 lg:block lg:w-full">
                                <path d="M56.327 31.224l-.036-.201c-.87-3.899-3.371-8.03-6.899-11.329-3.708-3.5-8.107-5.293-12.364-5.08-2.25.06-4.485.375-6.664.94-5.464 1.518-9.44 5.776-11.18 11.993a17.478 17.478 0 00.784 11.648 18.183 18.183 0 009.184 9.484 19.155 19.155 0 008.002 1.734c2.814-.02 5.595-.62 8.172-1.763a20.661 20.661 0 006.81-4.88c2.7-2.908 4.234-6.155 4.43-9.39.059-1.058-.022-2.12-.24-3.156zm-7.645-10.76c3.364 3.16 5.763 7.11 6.582 10.78l.035.193c.024.103.04.202.055.308v.048a12.85 12.85 0 01-3.221 4.227 12.736 12.736 0 01-4.646 2.547c-3.897 1.256-7.672-.79-9.8-2.978 1.568-1.647 2.434-3.16 2.595-4.483.243-1.975-.859-2.935-1.54-3.326-1.27-.723-3.015-.66-4.054.154a3.508 3.508 0 00-1.305 2.674c-.083 1.702.756 3.63 2.199 5.08a11.463 11.463 0 01-3.187 2.476 22.303 22.303 0 01-3.03-2.37c1.96-1.706 3.187-3.657 3.528-5.648.392-2.37-1.059-3.875-2.572-4.5-1.705-.714-4.057-.524-5.257 1.213-1.858 2.706-1.109 5.854 2.047 8.643a13.839 13.839 0 01-5.986 3.1l-.216.06h-.047a16.461 16.461 0 01-.67-10.835c1.639-5.846 5.35-9.85 10.439-11.28a28.653 28.653 0 016.444-.905c3.99-.182 8.123 1.552 11.607 4.823zM37.091 33.752c-.13.2-.268.402-.412.604a7.675 7.675 0 01-1.082-2.113 3.855 3.855 0 01.636-3.642 1.344 1.344 0 01.936-.497.603.603 0 01.169 0 1.248 1.248 0 01.878.813c.368.92.263 2.659-1.125 4.835zm-9.53-7.082c.341-.319.783-.505 1.247-.526h.165c.54.072 1.27.6 1.666 1.628.306.79.784 2.903-1.53 5.656-.309.372-.63.73-.96 1.067-1.215-1.446-1.834-2.82-1.83-4.08 0-2.18.678-3.243 1.242-3.745zm-3.598 12.36a19.108 19.108 0 004.426-2.438c2.207 1.84 3.242 2.469 3.528 2.615a1.741 1.741 0 001.873-.245l.153-.115a30.727 30.727 0 002.744-2.243 14.466 14.466 0 0010.33 3.065 12.568 12.568 0 008.353-4.179c-.45 2.607-1.827 5.194-4.018 7.564-5.704 6.138-14.46 8.015-21.795 4.673a17.143 17.143 0 01-8.232-8.062 10.45 10.45 0 002.638-.636zM86.052 38.44h-2.078v-9.183l-3.614 9.184h-.878l-3.626-9.184v9.184h-2.078V26.55h2.92l3.223 8.165 3.206-8.165h2.92l.005 11.89zM104.492 38.44h-2.352l-.863-2.298h-5.413l-.87 2.299H92.64l4.638-11.89h2.58l4.633 11.89zm-3.799-4.135l-2.125-5.664-2.136 5.664h4.261zM113.143 38.44h-2.074V26.552h5.202a3.698 3.698 0 012.811 1.07 3.938 3.938 0 011.019 2.647c0 .98-.363 1.924-1.019 2.647a3.73 3.73 0 01-1.296.824c-.483.182-.999.26-1.515.23h-3.136l.008 4.472zm2.85-6.292a2.043 2.043 0 001.442-.513 1.734 1.734 0 00.557-1.359 1.79 1.79 0 00-.553-1.375 2.043 2.043 0 00-1.442-.513h-2.85v3.76h2.846zM129.223 38.44h-2.074V26.553h2.074V38.44zM139.105 38.44h-2.074V26.553h8.087v1.836h-6.013v3.065h5.88v1.837h-5.88v5.15zM162.527 33.733c0 1.519-.435 2.72-1.305 3.602-.87.882-2.137 1.323-3.799 1.323-1.67 0-2.942-.444-3.818-1.331a4.871 4.871 0 01-1.305-3.594v-7.181h2.105v7.141a3.226 3.226 0 00.784 2.283 3.376 3.376 0 004.457 0 3.23 3.23 0 00.784-2.29v-7.134h2.109l-.012 7.18zM177.474 38.44h-7.275V26.553h2.073v10.052h5.202v1.837z" fill="inherit"></path>
                            </svg>
                        </a>
                        <div class="eHeadertext">
                            <h5>Customize your design</h5>
                            <p>Change location, labels and appearance</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <div id="celestial-form"></div>

    <!-- editor-area START -->
    <form id="bythis">
        <div class="editor-area">
            <div class="outout">
                <div class="tps" id="capture"> 
                    <div class="thePoster" data-orientation="sizePortrait" data-ppss="size50x70cm" id="theModern">
                        <div class="poster-body">
                            <div id="celestial-map"></div>
                            <h3 class="thisisMessageLine">Hello world</h3>
                            <div class="posterWrp">
                                <p class="tagline">JULY 13TH 2021</p>
                                <h4><span>NEW YORK</span>,<p class="divider">UNITED STATES</p></h4> 
                                <p class="subline">40.777°N / -73.873°N</p>
                            </div>
                            <div class="posterWrpBoxes">
                                <h4>Hello world</h4>
                                <p><span class="divider">dhaka</span>, <span class="subline">BANGLADESH</span> / <span class="taglines">September 10th 2019</span></p> 
                            </div>
                        </div>
                    </div> 
                </div>
            </div>
            <div class="editor">  
                <div class="accordion" id="accordionExample">
                    <div class="card">
                        <div class="card-header" id="headingOne"> 
                            <button class="btn btn-link btn-block collapsed text-left" type="button" data-toggle="collapse" data-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                                <span><i class="fal fa-angle-down"></i></span> Location and date 
                            </button> 
                        </div> 
                        <div id="collapseOne" class="collapse" aria-labelledby="headingOne" data-parent="#accordionExample">
                            <div class="card-body">
                                <div class="location"> 
                                    <div class="row">
                                        <div class="col-lg-12">
                                            <label for=""> 
                                                <div class="lc">
                                                    <input class="autoSuggest" type="text" placeholder="Start typing the name of a place" data-country="" data-city="" data-lat="" data-lon="">  <i class="fal fa-search"></i> 
                                                    <ul class="autoSuggestions"></ul>
                                                </div>
                                            </label>
                                        </div>
                                        <div class="col-lg-12">
                                            <div class="l-dats">   
                                                <span class="bdircts">Enter your specific date</span>
                                                <label for="" class="SelectionsHere"> 
                                                    <div class="dateSelects"> 
                                                        <select name="day" id="sDay">
                                                            <option value="01">01</option>
                                                            <option value="02">02</option>
                                                            <option value="03">03</option>
                                                            <option value="04">04</option>
                                                            <option value="05">05</option>
                                                            <option value="06">06</option>
                                                            <option value="07">07</option>
                                                            <option value="08">08</option>
                                                            <option value="09">09</option>
                                                            <option value="10">10</option>
                                                            <option value="11">11</option>
                                                            <option value="12">12</option>
                                                            <option value="13">13</option>
                                                            <option value="14">14</option>
                                                            <option value="15">15</option>
                                                            <option value="16">16</option>
                                                            <option value="17">17</option>
                                                            <option value="18">18</option>
                                                            <option value="19">19</option>
                                                            <option value="20">20</option>
                                                            <option value="21">21</option>
                                                            <option value="22">22</option>
                                                            <option value="23">23</option>
                                                            <option value="24">24</option>
                                                            <option value="25">25</option>
                                                            <option value="26">26</option>
                                                            <option value="27">27</option>
                                                            <option value="28">28</option>
                                                            <option value="29">29</option>
                                                            <option value="30">30</option>
                                                        </select>
                                                        <select name="month" id="sMonth">
                                                            <option value="Jan">Jan</option>
                                                            <option value="Fab">Fab</option>
                                                            <option value="Mar">Mar</option>
                                                            <option value="Apr">Apr</option>
                                                            <option value="May">May</option>
                                                            <option value="Jun">Jun</option>
                                                            <option value="Jul">Jul</option>
                                                            <option value="Aug">Aug</option>
                                                            <option value="Sep">Sep</option>
                                                            <option value="Oct">Oct</option>
                                                            <option value="Nov">Nov</option>
                                                            <option value="Dec">Dec</option>
                                                        </select>
                                                        <select name="year" id="sYear">
                                                            <option value="2021">2021</option>
                                                            <option value="2020">2020</option>
                                                            <option value="2019">2019</option>
                                                            <option value="2018">2018</option>
                                                            <option value="2017">2017</option> 
                                                        </select>
                                                    </div>
                                                    <div class="timesSelects"> 
                                                        <select name="hour" id="sHour">
                                                            <option value="01">01</option>
                                                            <option value="02">02</option>
                                                            <option value="03">03</option>
                                                            <option value="04">04</option>
                                                            <option value="05">05</option>
                                                            <option value="06">06</option>
                                                            <option value="07">07</option>
                                                            <option value="08">08</option>
                                                            <option value="09">09</option>
                                                            <option value="10">10</option>
                                                            <option value="11">11</option>
                                                            <option value="12">12</option>
                                                            <option value="13">13</option>
                                                            <option value="14">14</option>
                                                            <option value="15">15</option>
                                                            <option value="16">16</option>
                                                            <option value="17">17</option>
                                                            <option value="18">18</option>
                                                            <option value="19">19</option>
                                                            <option value="20">20</option>
                                                            <option value="21">21</option>
                                                            <option value="22">22</option>
                                                            <option value="23">23</option>
                                                            <option value="24">24</option>
                                                        </select> 
                                                        <small>:</small>
                                                        <select name="minute" id="sMinute">
                                                            <option value="01">01</option>
                                                            <option value="02">02</option>
                                                            <option value="03">03</option>
                                                            <option value="04">04</option>
                                                            <option value="05">05</option>
                                                            <option value="06">06</option>
                                                            <option value="07">07</option>
                                                            <option value="08">08</option>
                                                            <option value="09">09</option>
                                                            <option value="10">10</option>
                                                            <option value="11">11</option>
                                                            <option value="12">12</option>
                                                            <option value="13">13</option>
                                                            <option value="14">14</option>
                                                            <option value="15">15</option>
                                                            <option value="16">16</option>
                                                            <option value="17">17</option>
                                                            <option value="18">18</option>
                                                            <option value="19">19</option>
                                                            <option value="20">20</option>
                                                            <option value="21">21</option>
                                                            <option value="22">22</option>
                                                            <option value="23">23</option>
                                                            <option value="24">24</option>
                                                            <option value="25">25</option>
                                                            <option value="26">26</option>
                                                            <option value="27">27</option>
                                                            <option value="28">28</option>
                                                            <option value="29">29</option>
                                                            <option value="30">30</option>
                                                            <option value="31">31</option>
                                                            <option value="32">32</option>
                                                            <option value="33">33</option>
                                                            <option value="34">34</option>
                                                            <option value="35">35</option>
                                                            <option value="36">36</option>
                                                            <option value="37">37</option>
                                                            <option value="38">38</option>
                                                            <option value="39">39</option>
                                                            <option value="40">40</option>
                                                            <option value="41">41</option>
                                                            <option value="42">42</option>
                                                            <option value="43">43</option>
                                                            <option value="44">44</option>
                                                            <option value="45">45</option>
                                                            <option value="46">46</option>
                                                            <option value="47">47</option>
                                                            <option value="48">48</option>
                                                            <option value="49">49</option>
                                                            <option value="50">50</option>
                                                            <option value="51">51</option>
                                                            <option value="52">52</option>
                                                            <option value="53">53</option>
                                                            <option value="54">54</option>
                                                            <option value="55">55</option>
                                                            <option value="56">56</option>
                                                            <option value="57">57</option>
                                                            <option value="58">58</option>
                                                            <option value="59">59</option>
                                                            <option value="60">60</option>
                                                        </select>
                                                    </div>
                                                </label>
                                            </div>
                                        </div>  
                                    </div>  
                                </div>
                            </div>
                        </div>
                    </div> 
                    <div class="card">
                        <div class="card-header" id="headingOnet"> 
                            <button class="btn btn-link btn-block collapsed text-left" type="button" data-toggle="collapse" data-target="#collapseOnet" aria-expanded="true" aria-controls="collapseOnet">
                                <span><i class="fal fa-angle-down"></i></span> <ab>Customize the</ab> style 
                            </button> 
                        </div> 
                        <div id="collapseOnet" class="collapse" aria-labelledby="headingOnet" data-parent="#accordionExample">
                            <div class="card-body">
                                <div class="style">
                                    <div class="poster-layout">
                                        <fieldset id="layOuts">
                                            <ul>
                                                <li> 
                                                    <input type="radio" value="cicrleLayout" data-mapScale="1" id="layout1" name="layOuts" checked>
                                                    <label for="layout1"> <div class="layBox cicrcle"></div> Circle Layout</label>
                                                </li>
                                                <li>
                                                    <input type="radio" value="boxLayout" data-mapScale="1.5" id="layout2" name="layOuts">
                                                    <label for="layout2"> <div class="layBox"></div> Box Layout</label>
                                                </li> 
                                            </ul>
                                        </fieldset>
                                    </div>
                                    <div class="mapthestyles">
                                        <fieldset id="themeGroup">
                                            <ul>
                                                <li> 
                                                    <input type="radio" value="theModern" id="n1" name="themeGroup" checked>
                                                    <label for="n1"><img src="<?php echo e(asset('/')); ?>assets/img/themes/1.jpg" alt=""> Modern</label>
                                                </li>
                                                <li>
                                                    <input type="radio" value="Asphalt" id="n2" name="themeGroup">
                                                    <label for="n2"><img src="<?php echo e(asset('/')); ?>assets/img/themes/2.jpg" alt=""> Asphalt</label>
                                                </li>
                                                <li>
                                                    <input type="radio" value="Nautical" name="themeGroup" id="n3">
                                                    <label for="n3"><img src="<?php echo e(asset('/')); ?>assets/img/themes/3.jpg" alt=""> Nautical</label>
                                                </li>
                                                <li>
                                                    <input type="radio" value="Retro" name="themeGroup" id="n4">
                                                    <label for="n4"><img src="<?php echo e(asset('/')); ?>assets/img/themes/4.jpg" alt=""> Retro</label>
                                                </li>
                                                <li>
                                                    <input type="radio" value="Dark" name="themeGroup" id="n5">
                                                    <label for="n5"><img src="<?php echo e(asset('/')); ?>assets/img/themes/5.jpg" alt=""> Dark</label>
                                                </li>
                                                <li>
                                                    <input type="radio" value="Bright" name="themeGroup" id="n6">
                                                    <label for="n6"><img src="<?php echo e(asset('/')); ?>assets/img/themes/6.jpg" alt=""> Bright</label>
                                                </li>
                                                <li>
                                                    <input type="radio" value="Nisshoki" name="themeGroup" id="n7">
                                                    <label for="n7"><img src="<?php echo e(asset('/')); ?>assets/img/themes/7.jpg" alt=""> Nisshoki</label>
                                                </li>
                                                <li>
                                                    <input type="radio" value="Gaia" name="themeGroup" id="n8">
                                                    <label for="n8"><img src="<?php echo e(asset('/')); ?>assets/img/themes/8.jpg" alt=""> <span class="gtc">Collab!</span> Gaia</label>
                                                </li>
                                            </ul>
                                        </fieldset>
                                    </div>
                                    <div class="elements ckukblk"> 
                                        <ul>
                                            <li><span>Constellations</span> 
                                                <div class="checkboxes-and-radios">  
                                                    <input type="checkbox" name="checkbox-cats[]" id="checkbox" class="constelles" value="1" checked>
                                                    <label for="checkbox"> </label>  
                                                </div>
                                            </li>
                                            <li><span>Enable grid</span> 
                                                <div class="checkboxes-and-radios">  
                                                    <input type="checkbox" name="checkbox-cats[]" id="checkbox-2" class="enGrd" value="1" checked>
                                                    <label for="checkbox-2"> </label>  
                                                </div>
                                            </li> 
                                            <li><span>Milkyway</span> 
                                                <div class="checkboxes-and-radios">  
                                                    <input type="checkbox" name="checkbox-cats[]" id="checkbox-5" class="mlkw" value="1">
                                                    <label for="checkbox-5"> </label>  
                                                </div>
                                            </li> 
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div> 
                    <div class="card">
                        <div class="card-header" id="headingOneth"> 
                            <button class="btn btn-link btn-block collapsed text-left" type="button" data-toggle="collapse" data-target="#collapseOneth" aria-expanded="true" aria-controls="collapseOneth">
                                <span><i class="fal fa-angle-down"></i></span> <ab>Customize the</ab> text 
                            </button> 
                        </div> 
                        <div id="collapseOneth" class="collapse" aria-labelledby="headingOneth" data-parent="#accordionExample">
                            <div class="card-body">
                                <div class="themetext">
                                    <label for="">
                                        <span>Headline</span>
                                        <input type="text" value="Paris" name="" id="HeadLine" max="40">
                                    </label>
                                    <label for="">
                                        <span>Divider</span>
                                        <input type="text" value="France" name="" id="Devider">
                                    </label>
                                    <label for="">
                                        <span>Tagline</span>
                                        <input type="text" value="September 10th 2019" name="" id="TagLine" max="40">
                                    </label>
                                    <label for="">
                                        <span>Subline</span>
                                        <input type="text" value="48.856°N / 2.3522°E" name="" id="SubLine">
                                    </label>
                                    <label for="" class="theMessageField">
                                        <span>Mesage</span>
                                        <textarea name="" id="pMsg" placeholder="type your message">Hello world</textarea>
                                    </label>
                                </div>
                            </div>
                        </div>
                    </div> 
                    <div class="card">
                        <div class="card-header" id="headingOnef"> 
                            <button class="btn btn-link btn-block text-left" type="button" data-toggle="collapse" data-target="#collapseOnef" aria-expanded="true" aria-controls="collapseOnef">
                                <span><i class="fal fa-angle-down"></i></span> <ab>Change the</ab> size 
                            </button> 
                        </div> 
                        <div id="collapseOnef" class="collapse show" aria-labelledby="headingOnef" data-parent="#accordionExample">
                            <div class="card-body"> 
                                <div class="ppsizes">
                                    <div class="poster-size sizesIncenti">
                                        <p>Select poster size</p>
                                        <div class="theSSZZ active" data-class="centimiterAction"> 
                                            <input type="radio" data-height="826.8" data-width="590.6" data-scaling=".7" value="size30x40cm" name="radio-group" id="fsz">
                                            <label for="fsz">30x40cm</label>
                                            <input type="radio" data-height="826.8" data-width="590.6" data-scaling=".85" value="size50x70cm" name="radio-group" id="ssz">
                                            <label for="ssz">50x70cm</label>
                                            <input type="radio" data-height="826.8" data-width="590.6" data-scaling="1" value="size70x100cm" name="radio-group" id="tsz" checked>
                                            <label for="tsz">70x100cm</label> 
                                        </div>
                                        <div class="theSSZZ" data-class="inchAction"> 
                                            <input type="radio" data-height="826.8" data-width="590.6" data-scaling=".65" value='sInche11x17' name="radio-group" id="fsz1">
                                            <label for="fsz1">11x17"</label>
                                            <input type="radio" data-height="826.8" data-width="590.6" data-scaling=".75" value='sInche18x24' name="radio-group" id="ssz2">
                                            <label for="ssz2">18x24"</label>
                                            <input type="radio" data-height="826.8" data-width="590.6" data-scaling=".9" value='sInche24x36' name="radio-group" id="tsz3">
                                            <label for="tsz3">24x36"</label>
                                        </div>
                                        <div class="theSSZZ" data-class="ALabelAction"> 
                                            <input type="radio" data-height="826.8" data-width="590.6" data-scaling=".55" value='sInche11x17' name="radio-group" id="fsz001">
                                            <label for="fsz001">A4</label>
                                            <input type="radio" data-height="826.8" data-width="590.6" data-scaling=".75" value='sInche18x24' name="radio-group" id="ssz002">
                                            <label for="ssz002">A3</label>
                                            <input type="radio" data-height="826.8" data-width="590.6" data-scaling=".88" value='sInche24x36' name="radio-group" id="tsz003">
                                            <label for="tsz003">A2</label>
                                            <input type="radio" data-height="826.8" data-width="590.6" data-scaling=".95" value='sInche24x36' name="radio-group" id="tsz004">
                                            <label for="tsz004">A1</label>
                                        </div>
                                    </div>
                                    <div class="cngIt">Switch size standards <span class="centimiterAction active">CM (EU)</span> <span class="inchAction">Inch (US)</span> <span class="ALabelAction">A4-A1</span></div>
                                    <div class="orientation">
                                        <p>Select orientation</p>
                                        <input type="radio" value="sizePortrait" checked name="radio-grouptt" id="Portrait">
                                        <label for="Portrait">Portrait</label>
                                        <input type="radio" value="sizeLandscape" name="radio-grouptt" id="landscape">
                                        <label for="landscape">Landscape</label> 
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div> 
                </div>  
                <button type="button" class="save-design-text"  data-toggle="modal" data-target="#reminderModal"><i class="fal fa-envelope"></i> Save design and remind me later</button> 
                <div class="prices">
                    <img src="<?php echo e(asset('/')); ?>assets/img/Reload-Image-Gif-1.gif" alt="">
                    <button type="submit"><span class="thisistheposterPrice"><i class="fas fa-cart-plus"></i> USD 120.00</span> <div >ADD TO CART <i class="fas fa-long-arrow-right"></i></div> </button>
                </div>
            </div> 
        </div>
    </form>
    <!-- editor-area END -->
    <script src="<?php echo e(asset('/')); ?>assets/js/mobiscroll.javascript.min.js"></script>

    <script> 

        window.addEventListener('load',() => {
        
            let form             = document.querySelector('#bythis')
            let posterMessage    = document.querySelector('.thisisMessageLine')
            let posterPrice      = document.querySelector('.thisistheposterPrice')
            let place            = document.querySelector('.posterWrp h4')
            let TagLine          = document.querySelector('#TagLine')
            let TagLineTx        = document.querySelector('.tagline')
            let TagLineTx2       = document.querySelector('.taglines')
            let subline          = document.querySelector('.posterWrp .subline')
            let adtime           = document.querySelector('#datetime')
            let here             = document.querySelector('#here')

            let dass      = document.querySelector('#demo-datetime-day')
            let AllSc     = document.querySelectorAll('.SelectionsHere select')
            let sDay      = document.querySelector('#sDay')
            let sMonth    = document.querySelector('#sMonth')
            let sYear     = document.querySelector('#sYear')
            let sHour     = document.querySelector('#sHour')
            let sMinute   = document.querySelector('#sMinute')
            let AllMonths = ['','Jan',"Fab","Mar", "Apr", 'May', "Jun", "Jul",'Aug',"Sep","Oct","Nov",'Dec']; 


            function Sm(sDay,sMonth,sYear,sHour,sMinute) { 
                let monthIndex;
                AllMonths.forEach(lMnt => {
                    if (lMnt === sMonth.value) {
                        monthIndex = AllMonths.indexOf(lMnt);
                    }
                }); 
                const cStr1 = sMonth.value+" "+sDay.value+"th "+sYear.value;
                const cStr2 = sYear.value+"-"+monthIndex+"-"+sDay.value+" "+sHour.value+":"+sMinute.value;

                TagLine.value           = cStr1
                TagLineTx.innerHTML     = cStr1
                TagLineTx2.innerHTML    = cStr1 


                adtime.value = cStr2+":00 +0600";
                here.click();
    
            }
            AllSc.forEach(aItc => {
                aItc.addEventListener('change', () => {
                    Sm(sDay,sMonth,sYear,sHour,sMinute)
                })
            }); 

 
            form.addEventListener('submit', (e) => {
                e.preventDefault();   
                const myPromise = new Promise(function(myResolve, myReject) { 
                
                    // This is for the Final poster SIze
                    let upThis        = JSON.parse(localStorage.getItem('finalPoster'))
                    upThis.message    = posterMessage.textContent;
                    upThis.date       = TagLineTx.textContent;
                    upThis.latlon     = subline.textContent;
                    upThis.place      = place.textContent;
                    upThis.cartActivat= 'yes';
                    upThis.price      = posterPrice.textContent;  
                    localStorage.setItem('finalPoster',JSON.stringify(upThis))
                    
                    let gettingData   = JSON.parse(localStorage.getItem('finalPoster'))
                    let posterIsReady =  {
                        place: gettingData.place,
                        message:gettingData.message,
                        date: gettingData.date,
                        latlon: gettingData.latlon,
                        posterStyle: gettingData.posterStyle,
                        posterTheme: gettingData.posterTheme,
                        Constellations: gettingData.Constellations,
                        Enablegrid: gettingData.Enablegrid,
                        Milkyway: gettingData.Milkyway,
                        posterSize: gettingData.posterSize,
                        orientation: gettingData.orientation,
                        price: gettingData.price,
                        cartActivat: gettingData.cartActivat,
                        posterImage: "",
                        posterMap: ""
                    }
                    localStorage.setItem('finalPosterSend',JSON.stringify(posterIsReady))

  
                    window.scrollTo(0, 0);   
                    html2canvas(document.getElementById("theModern")).then(function (canvas) { 
                        let upThis        = JSON.parse(localStorage.getItem('finalPosterSend'))
                        upThis.posterImage= canvas.toDataURL("image/jpeg", 0.9)
                        localStorage.setItem('finalPosterSend',JSON.stringify(upThis))
                    });
                    html2canvas(document.getElementById("celestial-map")).then(function (canvas) { 
                        let upThis        = JSON.parse(localStorage.getItem('finalPosterSend')) 
                        upThis.posterMap  = canvas.toDataURL("image/jpeg", 0.9)
                        localStorage.setItem('finalPosterSend',JSON.stringify(upThis))
 
                        myResolve("I love You !!")

                        localStorage.removeItem("finalPoster");

                    }); 
                    form.classList.add('loading')
 
                });
                const lastRun   = () => { 
                    window.location.replace(window.location.origin+"/checkout");
                }
                myPromise.then(function() {
                    lastRun()
                }); 

            })


        }) 



 
    </script>  





<?php $__env->stopSection(); ?>
<?php echo $__env->make('content-layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\dnsna\OneDrive\Desktop\blog\resources\views/editor.blade.php ENDPATH**/ ?>