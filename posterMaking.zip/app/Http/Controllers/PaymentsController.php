<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class PaymentsController extends Controller
{
    // Checkout page
    public function index()
    {
        return view('payment');
    }
}
