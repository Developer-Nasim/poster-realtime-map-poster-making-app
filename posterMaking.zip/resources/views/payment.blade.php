@extends('content-layout.layout')
@section('thecontents')
 

    @section('title') Let's just checkout here pleasea @endsection
        <!-- Header-area START -->
        <div class="Header-area white-header">
            <div class="header-top">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-12 text-center">
                            <p>DISCOUNT 20% ALL ITEM - READ MORE</p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="header-main">
                <div class="container">
                    <div class="row align-items-center">
                        <div class="col-2 d-block d-lg-none">
                            <div class="menu-icon">
                                <div class="in-mobile"> 
                                    <a href="javascript:void(0)" class="humg-btn"><span></span></a> 
                                </div> 
                            </div>
                        </div>
                        <div class="col-lg-2 col-8">
                            <div class="logo-area">
                                <a href="index.html"><img src="assets/img/logo.png" alt=""></a>
                            </div>
                        </div>
                        <div class="col-lg-7 d-none d-lg-block text-center">
                            <div class="menu-area">
                                <nav>
                                    <ul>
                                        <li><a href="index.html">Home</a></li> 
                                        <li><a href="services.html">tearms</a></li>
                                        <li><a href="faq.html">FAQs</a></li>
                                        <li><a href="contact.html">Contact</a></li>
                                    </ul>
                                </nav>
                            </div>
                        </div>
                        <div class="col-lg-3 col-2 text-right">
                            <div class="header-action">
                                <ul>
                                    <li class="poster-btn"><a href="#">Create your poster</a></li>
                                    <li>
                                        <select>
                                            <option>usd</option>
                                            <option>aud</option>
                                            <option>cud</option>
                                        </select>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="Header-area sticky-header">
            <div class="header-top">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-12 text-center">
                            <p>DISCOUNT 20% ALL ITEM - READ MORE</p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="header-main">
                <div class="container">
                    <div class="row align-items-center">
                        <div class="col-2 d-block d-lg-none">
                            <div class="menu-icon">
                                <div class="in-mobile"> 
                                    <a href="javascript:void(0)" class="humg-btn"><span></span></a> 
                                </div> 
                            </div>
                        </div>
                        <div class="col-lg-2 col-8">
                            <div class="logo-area">
                                <a href="index.html"><img src="assets/img/logo.png" alt=""></a>
                            </div>
                        </div>
                        <div class="col-lg-7 d-none d-lg-block text-center">
                            <div class="menu-area">
                                <nav>
                                    <ul>
                                        <li><a href="index.html">Home</a></li> 
                                        <li><a href="services.html">tearms</a></li>
                                        <li><a href="faq.html">FAQs</a></li>
                                        <li><a href="contact.html">Contact</a></li>
                                    </ul>
                                </nav>
                            </div>
                        </div>
                        <div class="col-lg-3 col-2 text-right">
                            <div class="header-action">
                                <ul>
                                    <li class="poster-btn"><a href="#">Create your poster</a></li>
                                    <li>
                                        <select>
                                            <option>usd</option>
                                            <option>aud</option>
                                            <option>cud</option>
                                        </select>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
         <!-- mobile-menu -->
         <div class="mobile-menu">
            <a href="javascript:void(0)" class="humg-btn"><i class="fal fa-times"></i></a> 
            <nav>
                <ul>
                    <li><a href="index.html">Home</a></li> 
                    <li><a href="services.html">tearms</a></li>
                    <li><a href="faq.html">FAQs</a></li>
                    <li><a href="contact.html">Contact</a></li>
                </ul>
            </nav> 
        </div> 
        <!-- Header-area END -->
           
        <!-- main START -->
        <main class="bellingPage"> 


            <!-- cart-area START -->
            <div class="cart-area">
                <div class="container">

                    <!-- section-title -->
                    <div class="row">
                        <div class="col-lg-8 offset-lg-2 text-center">
                            <div class="section-title">
                                <h1>COMPLETE YOUR PURCHASE</h1>  
                            </div>
                        </div>
                    </div> 
                    
                    <!-- carts -->
                    <div class="row"> 
                        <div class="col-lg-8 offset-lg-2">
                            <h5 class="producTitles">Products</h5>
                            <button type="button" class="removeThisProduct">Remove Product <i class="far fa-trash-alt"></i></button>
                        </div>
                        <div class="col-lg-8 offset-lg-2"> 
                            <div class="myProductHere">
                                <img src="https://mapiful.nyc3.digitaloceanspaces.com/prints/previews/starmaps/2021/7/a23f5ba4fe993a1a5afeaa8db45ab444e6e2a773.jpeg" alt="">
                                <div class="mprContents">
                                    <h4>50×70cm - Portrait (Starmap)</h4>
                                    <p>
                                        <span class="pcity">Paris</span>
                                        <span class="pcountry">France</span>
                                        <span class="pdate">SEPTEMBER 10TH 2019</span>
                                        <span class="platlon">48.856°N / 2.3522°E</span>
                                        <b>1 × €49</b>
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- cart-area END --> 

            <!-- shoping-method START -->
            <div class="shoping-method">
                <div class="container"> 
                    <!-- section-title -->
                    <div class="row">
                        <div class="col-lg-8 offset-lg-2 col-md-8 offset-md-2">
                            <div class="section-title">
                                <h1>SHIPPING METHOD</h1>  
                            </div>
                        </div>
                    </div>
                    <fieldset>
                        <div class="row">
                            <div class="col-lg-4 offset-lg-2 col-md-6">
                                <div class="method-blk">  
                                    <input type="radio" value="First Class Shipping" id="fruit1" name="fruit-1" checked>
                                    <label for="fruit1">
                                        <h5>1ST CLASS SHIPPING <span>$2.00</span></h5>
                                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing</p>
                                    </label>   
                                </div>
                            </div>
                            <div class="col-lg-4 col-md-6">
                                <div class="method-blk">  
                                    <input type="radio" value="Second Class Shipping" id="nd" name="fruit-1">
                                    <label for="nd">
                                        <h5>2nd CLASS SHIPPING <span>$1.50</span></h5>
                                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing</p>
                                    </label>   
                                </div>
                            </div>
                        </div>
                    </fieldset>    
                </div>
            </div>
            <!-- shoping-method END -->

            <!-- billin-details-area START -->
            <div class="billin-details-area">
                <div class="container">
                    <!-- section-title -->
                    <div class="row">
                        <div class="col-lg-8 offset-lg-2 col-md-8 offset-md-2">
                            <div class="section-title">
                                <h1>BILLING DETAILS</h1>  
                            </div>
                        </div>
                    </div> 
                    

                    <div class="row">
                        <div class="col-lg-8 offset-lg-2">
                            <div class="contact-from billing">
                                <div class="row">
                                    <div class="col-lg-12">
                                        <p>Email Address</p>
                                        <input type="text" placeholder="Your Email">
                                    </div>
                                    <div class="col-md-6">
                                        <p>First Name</p>
                                        <input type="text" placeholder="Your First Name">
                                    </div>
                                    <div class="col-md-6">
                                        <p>Last Name</p>
                                        <input type="text" placeholder="Your Last Name">
                                    </div>
                                    <div class="col-md-6">
                                        <p>Company Name ( Optional )</p>
                                        <input type="text" placeholder="Your Company Name">
                                    </div>
                                    <div class="col-md-6">
                                        <p>County ( Optional )</p>
                                        <input type="text" placeholder="Your County Name">
                                    </div>
                                    <div class="col-md-6">
                                        <p>Postcode</p>
                                        <input type="text" placeholder="Your Postcode">
                                    </div>
                                    <div class="col-md-6">
                                        <div class="checkboxes-and-radios">  <input type="checkbox" name="checkbox-cats[]" id="checkbox-1" value="1" checked>
                                            <label for="checkbox-1"> </label> 
                                            <span>Deliver to different address</span>
                                        </div>
                                    </div>
                                    <div class="col-lg-12">
                                        <p>Order Notes ( Optional )</p>
                                        <textarea class="message" placeholder="Notes About Your Order, e.g. Special Notes for Delivery"></textarea>
                                    </div>
                                    <div class="col-lg-12"> 
                                        <div id="accordion"> 
                                            <div class="card">
                                                <div class="card-header" id="headingOne"> 
                                                    <button class="btn btn-link" data-toggle="collapse" data-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                                                        <input type="checkbox" id="Cardss" checked>
                                                        <label for="Cardss"> 
                                                            <p> Credit / Debit Card ( Stripe )</p>
                                                        </label> 
                                                    </button> 
                                                </div> 
                                                <div id="collapseOne" class="collapse show" aria-labelledby="headingOne" data-parent="#accordion">
                                                    <div class="card-body">
                                                        <h4>Pay with your Credit / Debit Card via Stripe</h4> 
                                                        <div class="contact-from">
                                                            <div class="row">
                                                                <div class="col-lg-12">
                                                                    <p>Card Number</p>
                                                                    <input type="text" placeholder="1234 5678 90">
                                                                </div>
                                                                <div class="col-md-6 col-sm-12">
                                                                    <p>Expire Date</p>
                                                                    <input type="text" placeholder="MM / YY">
                                                                </div> 
                                                                <div class="col-md-6 col-sm-12">
                                                                    <p>Card Code ( CVC )</p>
                                                                    <input type="text" placeholder="CVC">
                                                                </div> 
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div> 
                                        </div>
                                    </div> 
                                    <div class="col-lg-12 text-center">
                                        <div class="privacy-wrp">
                                            <p>Your personal data will be used to process your order, support your experience
                                                throughout this website and for other purposes described in our <a href="services.html"><b><i>privacy policy.</i></b></a></p> 
                                                <input type="checkbox" id="AND">
                                                <label for="AND" class="allterms"> 
                                                    <p>I HAVE READ AND AGREE TO THE WEBSITE <a href="./services.html"> TERMS AND CONDITIONS</a></p>
                                                </label>  
                                            <button type="submit" class="contact-btn btn">SUBMIT</button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- billin-details-area END -->

            <!-- features-area START -->
            <div class="features-area"> 
                <div class="container"> 
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="all-blks"> 
                                <div class="feature-blk">
                                    <span><i class="fas fa-globe-americas"></i></span>
                                    <h4>WORLD WIDE SHIPPING <p>Fast and reliable deliveries</p></h4> 
                                </div> 
                                <div class="feature-blk">
                                    <span><i class="fas fa-gift"></i></span>
                                    <h4>THE PERFECT GIFT <p>Unique and personal</p></h4> 
                                </div> 
                                <div class="feature-blk">
                                    <span><i class="fas fa-star"></i></span>
                                    <h4>HIGH QUALITY PRODUCTS <p>Our Product stands the test of time</p></h4> 
                                </div> 
                                <div class="feature-blk">
                                    <span><i class="fas fa-comments"></i></span>
                                    <h4>OUTSTANDING SUPPORT <p>Always here to help when needed</p></h4> 
                                </div>
                            </div> 
                        </div> 
                    </div>
                </div>
            </div>
            <!-- features-area END -->
 

        </main>
        <!-- main END -->
 

        <script>
 
            function ValidePage() { 
                let rmBtn = document.querySelector('.removeThisProduct') 
                let upThis        = JSON.parse(localStorage.getItem('finalPosterSend'))
                if (upThis.cartActivat === 'no') {
                    window.location.replace(window.location.origin+"/editor");
                }
                rmBtn.addEventListener("click", () => {
                    localStorage.removeItem("finalPosterSend");
                    window.location.replace(window.location.origin+"/editor");
                })
            }
            ValidePage()

            function postRend() {
                let thatBox = document.querySelector('.myProductHere');
                let thatBIm = thatBox.querySelector('img'); 

                let upThis        = JSON.parse(localStorage.getItem('finalPosterSend'))
                thatBIm.src       = upThis.posterImage; 

            } 
            postRend()




        </script>

@endsection